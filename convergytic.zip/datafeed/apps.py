from django.apps import AppConfig


class DatafeedConfig(AppConfig):
    name = 'datafeed'
